# langchain-abso

This package contains the LangChain integration with Abso

## Installation

```bash
pip install -U langchain-abso
```

And you should configure credentials by setting the following environment variables:

* TODO: fill this out

## Chat Models

`ChatAbso` class exposes chat models from Abso.

```python
from langchain_abso import ChatAbso

llm = ChatAbso()
llm.invoke("Sing a ballad of LangChain.")
```

## Embeddings

`AbsoEmbeddings` class exposes embeddings from Abso.

```python
from langchain_abso import AbsoEmbeddings

embeddings = AbsoEmbeddings()
embeddings.embed_query("What is the meaning of life?")
```

## LLMs
`AbsoLLM` class exposes LLMs from Abso.

```python
from langchain_abso import AbsoLLM

llm = AbsoLLM()
llm.invoke("The meaning of life is")
```
